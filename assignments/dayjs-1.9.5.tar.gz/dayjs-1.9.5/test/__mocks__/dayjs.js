const dayjs = require('../../src')

module.exports = dayjs
